<?php
    //API Key - see http://admin.mailchimp.com/account/api
    $apikey = '6319be4fd36db70acb816bd35c55641b-us6';
    
    // A List Id to run examples against. use lists() to view all
    // Also, login to MC account, go to List, then List Tools, and look for the List ID entry
    //$listId = '98f9700bbe';
    $listId = '1954eb8429';
    
    //just used in xml-rpc examples
    $apiUrl = 'http://api.mailchimp.com/1.3/';
    
?>
